export class GetVersionResponse {
    public Version!: string
}