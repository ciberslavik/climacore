export class CalculateResponse {
    public Result!: string
}