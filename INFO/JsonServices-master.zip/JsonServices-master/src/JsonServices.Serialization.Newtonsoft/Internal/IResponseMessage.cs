﻿namespace JsonServices.Serialization.Newtonsoft.Internal
{
	internal interface IResponseMessage
	{
		object Result { get; }
	}
}
