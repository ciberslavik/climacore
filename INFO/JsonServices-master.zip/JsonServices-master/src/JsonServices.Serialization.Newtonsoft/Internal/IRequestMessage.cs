﻿namespace JsonServices.Serialization.Newtonsoft.Internal
{
	internal interface IRequestMessage
	{
		object Parameters { get; }
	}
}
