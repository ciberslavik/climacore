﻿namespace JsonServices
{
	public interface IReturn<T>
	{
	}
}
