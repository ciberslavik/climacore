﻿namespace JsonServices
{
	public interface IReturnVoid
	{
	}
}
