﻿namespace JsonServices.Services
{
	public class VersionResponse
	{
		public string ProductName { get; set; }

		public string ProductVersion { get; set; }

		public string EngineVersion { get; set; }
	}
}
