﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("JsonServices.Tests")]
[assembly: InternalsVisibleTo("JsonServices.Transport.Fleck.Tests")]
[assembly: InternalsVisibleTo("JsonServices.Transport.WebSocketSharp.Tests")]
[assembly: InternalsVisibleTo("JsonServices.Auth.SecureRemotePassword")]
[assembly: InternalsVisibleTo("JsonServices.Auth.SecureRemotePassword.Tests")]
