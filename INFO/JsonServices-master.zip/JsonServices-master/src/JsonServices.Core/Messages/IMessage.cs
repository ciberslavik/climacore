﻿namespace JsonServices.Messages
{
	public interface IMessage
	{
		string Version { get; }
	}
}
