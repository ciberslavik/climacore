﻿namespace JsonServices.Tests.Messages
{
	public class GetVersionResponse
	{
		public string Version { get; set; }
	}
}