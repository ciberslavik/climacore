﻿namespace JsonServices.Tests.Messages
{
	public class CalculateResponse
	{
		public decimal Result { get; set; }
	}
}
