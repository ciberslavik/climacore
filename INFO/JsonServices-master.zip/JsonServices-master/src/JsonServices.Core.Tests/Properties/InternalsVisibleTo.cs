﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("JsonServices.Auth.SecureRemotePassword.Tests")]
