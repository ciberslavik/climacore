﻿namespace JsonServices.Serialization.ServiceStack.Internal
{
	internal interface IResponseMessage
	{
		object Result { get; }
	}
}
