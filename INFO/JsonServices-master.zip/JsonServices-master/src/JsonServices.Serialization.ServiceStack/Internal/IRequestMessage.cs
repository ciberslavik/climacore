﻿namespace JsonServices.Serialization.ServiceStack.Internal
{
	internal interface IRequestMessage
	{
		object Parameters { get; }
	}
}
