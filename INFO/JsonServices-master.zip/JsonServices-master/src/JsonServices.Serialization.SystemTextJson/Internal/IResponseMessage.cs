﻿namespace JsonServices.Serialization.SystemTextJson.Internal
{
	internal interface IResponseMessage
	{
		object Result { get; }
	}
}
