﻿namespace JsonServices.Serialization.SystemTextJson.Internal
{
	internal interface IRequestMessage
	{
		object Parameters { get; }
	}
}
